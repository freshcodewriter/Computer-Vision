Run the project:
python main.py

Input images are in /img.

Output images are in /res.