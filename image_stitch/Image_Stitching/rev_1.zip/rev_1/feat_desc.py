'''
  File name: feat_desc.py
  Author:
  Date created:
'''

'''
  File clarification:
    Extracting Feature Descriptor for each feature point. You should use the subsampled image around each point feature, 
    just extract axis-aligned 8x8 patches. Note that it’s extremely important to sample these patches from the larger 40x40 
    window to have a nice big blurred descriptor. 
    - Input img: H × W matrix representing the gray scale input image.
    - Input x: N × 1 vector representing the column coordinates of corners.
    - Input y: N × 1 vector representing the row coordinates of corners.
    - Outpuy descs: 64 × N matrix, with column i being the 64 dimensional descriptor (8 × 8 grid linearized) computed at location (xi , yi) in img.
'''
import numpy as np

# # Hand Write feature desciptor
def feat_desc(img, x, y):
    
    patch_size = 8
    space = 5
    vx = np.arange(-space * patch_size/2, space * patch_size/2, space)
    vy = vx
    patch_x, patch_y = np.meshgrid(vx,vy)
    patch_x[:,int(patch_size/2):] += space
    patch_y[int(patch_size/2):,:] += space
    patch_x, patch_y = patch_x.flatten(), patch_y.flatten()
    
    offset_x = np.tile(patch_x,(x.shape[0],1)) + np.tile(np.array([x]).T, (1, patch_x.shape[0]))
    offset_y = np.tile(patch_y,(y.shape[0],1)) + np.tile(np.array([y]).T, (1, patch_y.shape[0]))
    offset_x = np.clip(offset_x, 0, img.shape[1] - 1).astype(np.int32)
    offset_y = np.clip(offset_y, 0, img.shape[0] - 1).astype(np.int32)
    
    des = np.zeros((x.shape[0], patch_size*patch_size)) 
    des = img[offset_y, offset_x].astype(np.float64)

    for i in range(0, des.shape[0]):
        des[i] = des[i] - np.mean(des[i])
        norm = np.linalg.norm(des[i])
        des[i] = des[i] / norm

    return des

